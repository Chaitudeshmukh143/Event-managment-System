package com.pack.event_managment_system;

public interface DBInfo 
{
	public static final String driver="jdbc.oracle.OracleDriver";
	public static final String dburl="jdbc:oracle:thin:@localhost:1521:orcl";
	public static final String user="system";
	public static final String pass="123";

}
